#include "Edge.hpp"

Edge::Edge(Node source, Node destiny) {
    this->source = source;
    this->destiny = destiny;
}

Edge::Edge() {

}

Edge::~Edge() {

}