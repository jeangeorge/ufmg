#include "Node.hpp"

Node::Node(int id, int age) {
    this->id = id;
    this->age = age;
}

Node::Node() {

}

Node::~Node() {

}