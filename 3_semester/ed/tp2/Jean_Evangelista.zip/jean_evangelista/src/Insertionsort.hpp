#ifndef TP2_ED_INSERTIONSORT_HPP
#define TP2_ED_INSERTIONSORT_HPP

void insertionSort(int *array, int left, int right, int *movInsertion, int *compInsertion);

#endif //TP2_ED_INSERTIONSORT_HPP
