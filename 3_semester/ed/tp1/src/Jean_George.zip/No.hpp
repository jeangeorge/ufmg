#ifndef NO_H
#define NO_H

template <class T> class No
{
	public:
		T dado;
		No* proximo;
		No();
		~No();
};

#endif
