#include "MiniSisu.hpp"

int main() {
	MiniSisu* sisu = new MiniSisu();
	delete sisu;
	return 0;
}
