package interno.projeto;

public enum ProjetoEnum {
  NORMAL, REFORMA
}
